package board.controller;

public class Board {

}
